
package com.anushkrish.cms.services;

import com.anushkrish.cms.model.Customer;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
@Component
public class CustomerServices {
    private int CustomerIdCount=1;

    private List<Customer> CustomerList=new CopyOnWriteArrayList<>();

    public Customer addCustomer(Customer customer){
        customer.setCustomerId(CustomerIdCount);
        CustomerList.add(customer);
       // CustomerList.add(customer);
        CustomerIdCount++;
        return customer;

    }
    public List<Customer> getCustomers(){
        return CustomerList;
    }


    public Customer getCustomer(int customerId){
        return CustomerList
                .stream()    //stream is used for operations in which original data structure is not affected.one stream can be used only once.
                .filter(c -> c.getCustomerId()==customerId)
                .findFirst()
                .get();
    }
    public Customer updateCustomer(int customerId,Customer customer){
        CustomerList
                .stream()
                .forEach(c-> {
                    if(c.getCustomerId()==customerId){
                        c.setCustomerFirstName(customer.getCustomerFirstName());
                        c.setCustomerLastName(customer.getCustomerLastName());
                        c.setCustomerEmail(customer.getCustomerEmail());
                    }

                });
        return CustomerList
                .stream()
                .filter(c -> c.getCustomerId()==customerId)
                .findFirst()
                .get();


    }
    public void deleteCustomer(int customerId){
        CustomerList
                .stream()
                .forEach(c->  {
                    if(c.getCustomerId()==customerId){
                        CustomerList.remove(c);
                    }
                        });
    }

}
